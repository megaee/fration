# -*- coding: utf-8 -*-
"""
Created on Sat Apr 18 11:09:16 2020

@author: Dell
"""

ignore_lines=[]

ignore_variables = []
ignore_register_data = []
